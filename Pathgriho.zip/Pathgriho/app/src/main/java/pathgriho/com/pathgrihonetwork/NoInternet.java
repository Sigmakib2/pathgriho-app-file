package pathgriho.com.pathgrihonetwork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import io.github.muddz.styleabletoast.StyleableToast;

public class NoInternet extends AppCompatActivity {

    FloatingActionButton flobutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_internet);

        StyleableToast.makeText(this, "আপনার ইন্টারনেট সংযোগ বন্ধ আছে! সংযোগ চালু করে Retry বাটনে ক্লিক করুন।", Toast.LENGTH_LONG, R.style.noInternet).show();


        //floating button section
        flobutton = findViewById(R.id.floatingButt);
        flobutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(NoInternet.this, PathgrihoMainSite.class));
            }
        });

    }
}